---
name: get-started
description: First-run setup for Proffix Px5 (pfx-mcp). Use when the user wants to connect Proffix or run an ERP query. Reply in the user's language. A pfx MCP API key is mandatory.
---

# Get started with Proffix Px5 (pfx-mcp)

## Language

Reply in the language of the user's latest message. Do not switch to English only because this file is written in English.

## Goal

Connect one Proffix mandant and verify a search works. Secrets stay on the MCP server; never ask the user to paste passwords into chat after the first profile create.

## Steps

1. Call `list_connection_profiles`.
2. If empty, call `create_connection_profile` with:
   - `name` (e.g. "Mein Proffix")
   - `apiKey` (pfx-mcp API key)
   - `url`, `port`, `database`, `username`, `password` (Proffix REST)
   - optional `group` for customer grouping
   - optional `readOnly: true` to lock the profile to GET/report-only
3. Call `get_active_profile` (first profile is activated automatically).
4. Smoke: `call_on_profile` (or `read_from_profile`) with `tool: px_search_addresses` and a short `query` (e.g. "Muster"), or ask the user for a known name/Ort.
5. Confirm the reply has no password/API key fields.

## Rules

- Confirm create/update/delete Proffix records with the user before calling write tools.
- Prefer `call_on_profile` / `compare_profiles` over inventing `listeNr`.
- `compare_profiles` is read-only (no writes, no sync/copy between mandants).
- Reports (`px_generate_report`) must run alone (FCGI ~30s).
- For a second mandant: create another profile, then `compare_profiles` or switch with `set_active_profile`.
