---
name: get-started
description: Ersteinrichtung für Proffix Px5. Nutzen, wenn jemand Proffix verbinden, Profile anzeigen oder eine erste Lese-Abfrage starten will. Antworten auf Deutsch, ausser die Person schreibt in einer anderen Sprache.
---

# Ersteinrichtung Proffix Px5

## Sprache

Antworte auf Deutsch. Wechsle nur, wenn die letzte Nachricht klar in einer anderen Sprache geschrieben ist.

## Ziel

Einen Mandanten über OAuth verbinden und eine Lese-Abfrage prüfen. Secrets gehören nie in den Chat.

## Anmeldung (OAuth)

API-Key und Proffix-Passwort **nicht** im Chat abfragen und **nicht** wiederholen. Die Anmeldung läuft über OAuth: `create_connection_profile` ohne Argumente öffnet die sichere Connect-Seite auf mcp.pfx.ch. Dort trägt die Person die Zugangsdaten selbst ein.

## Rechte

Der Connector erbt die Proffix-ERP-Berechtigungen des verbundenen Benutzers. Module oder Datensätze ohne Proffix-Recht sind über das Plugin ebenfalls nicht erreichbar — wie im nativen Proffix-Client. Keine Rechte erweitern oder umgehen.

## Schritte

1. `list_connection_profiles` aufrufen.
2. Weiteren Mandanten anlegen oder Credentials rotieren: `create_connection_profile` ohne Argumente — öffnet die Connect-Seite. Nie `apiKey`/`password` an Tools übergeben.
3. Metadaten (Name, URL, Port, DB, User, readOnly) mit `update_connection_profile` anpassen — ohne Secrets.
4. `get_active_profile` prüfen. Das beim Verbinden gespeicherte Profil ist aktiv.
5. Kurz testen: `call_on_profile` oder `read_from_profile` mit `px_search_addresses` und einem Namen, den die Person nennt.
6. In der Antwort dürfen kein Passwort und kein API-Key stehen.

## Regeln

- Anlegen, Ändern und Löschen erst nach ausdrücklicher Bestätigung.
- `listeNr` nicht erfinden, sondern über die Suche auflösen.
- `compare_profiles` nur zum Lesen, nicht zum Kopieren zwischen Mandanten.
- Listen (`px_generate_report`) einzeln ausführen.
- Keine Lohn-/AHV-/Payslip-Workflows in diesem Onboarding anleiten.