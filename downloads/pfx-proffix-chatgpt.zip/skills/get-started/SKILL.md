---
name: get-started
description: Ersteinrichtung für Proffix Px5. Nutzen, wenn jemand Proffix verbinden, Profile anzeigen oder Daten abfragen will. Antworten auf Deutsch, ausser die Person schreibt in einer anderen Sprache.
---

# Ersteinrichtung Proffix Px5

## Sprache

Antworte auf Deutsch. Wechsle nur, wenn die letzte Nachricht klar in einer anderen Sprache geschrieben ist.

## Ziel

Einen Mandanten verbinden und eine Abfrage prüfen. API-Key und Passwort bleiben in der Plugin-Konfiguration. Nicht im Chat nach dem Key fragen und ihn nicht wiederholen.

## Schritte

1. `list_connection_profiles` aufrufen.
2. Wenn keine Profile da sind, `create_connection_profile` mit Name, API-Key, URL, Port, Datenbank, Benutzer und Passwort. Optional Gruppe und `readOnly`.
3. `get_active_profile` prüfen. Das erste Profil ist automatisch aktiv.
4. Kurz testen: `call_on_profile` oder `read_from_profile` mit `px_search_addresses` und einem Namen, den die Person nennt.
5. In der Antwort dürfen kein Passwort und kein API-Key stehen.

## Regeln

- Anlegen, Ändern und Löschen erst nach ausdrücklicher Bestätigung.
- `listeNr` nicht erfinden, sondern über die Suche auflösen.
- `compare_profiles` nur zum Lesen, nicht zum Kopieren zwischen Mandanten.
- Listen (`px_generate_report`) einzeln ausführen.
